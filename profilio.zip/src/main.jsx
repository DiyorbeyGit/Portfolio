import Home from "./pages/apps/home";
import ETC from "./others/apps/etc";
import { useState } from "react";
import About from "./pages/apps/about";
import Skills from "./pages/apps/skils";
import Services from "./pages/apps/exp";
import Contact from "./pages/apps/contact";
import Education from "./pages/apps/education";
import Navbar from "./components/apps/navbar";
import Footer from "./components/apps/footer";
function Main() {
  const [show, setShow] = useState(false);
  window.addEventListener("scroll", () => {
    if (window.scrollY > 100) {
      setShow(true);
    } else {
      setShow(false);
    }
  });
  const move = (e) => {
    document.querySelector("#cursour").style.top = e.clientY + 0 + "px";
    document.querySelector("#cursour").style.left = e.clientX + 0 + "px";
    document.querySelector("#cursour2").style.top = e.clientY + 5 + "px";
    document.querySelector("#cursour2").style.left = e.clientX + 5 + "px";
    document.querySelector("#cursour3").style.top = e.clientY + 10 + "px";
    document.querySelector("#cursour3").style.left = e.clientX + -10 + "px";
  };
  return (
    <section onMouseMove={(e) => move(e)}>
      <Navbar/>
      <Home />
      <About/>
      <Education/>
      <Skills/>
      <Services/>
      <Contact/>
      <ETC show={show}/>
      <Footer/>
    </section>
  );
}

export default Main;
