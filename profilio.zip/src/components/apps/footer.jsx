import '../styles/footer.scss';
function Footer() {
    return ( 
        <div className="footer">
            <h1>Made width 😀 Diyorbek </h1>
        </div>
     );
}
export default Footer;