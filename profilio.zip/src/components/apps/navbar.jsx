import { Link } from "react-router-dom";
import { useState } from "react";
import Logo from "../../images/res-w.png";
import "../styles/navbar.scss";
import Fade from "react-reveal/Fade";

function Navbar() {
  const [show, setShow] = useState(false);
  const moveTo = (e) => {
    const to = document.querySelector(e).offsetTop;
    window.scrollTo({
      top: to,
      behavior: "smooth",
    });
    setShow(false);
  };
  return (
    <nav className={!show ? null : "active"}>
      <div className="logo">
        <Link
          to="/"
          onClick={() => {
            moveTo(".home");
          }}
        >
          <img src={Logo} alt="Logo" />
        </Link>
      </div>
      <div className="link" onClick={() => setShow(!show)}>
        <Fade left cascade>
          <div className="links">
            <Link
              to="/"
              onClick={() => {
                moveTo(".landing");
              }}
            >
              <p>Asosiy sahifa</p>
            </Link>
            <Link
              to="/about"
              onClick={() => {
                moveTo(".about");
              }}
            >
              <p>Men haqimda</p>
            </Link>
            <Link
              to="/education"
              onClick={() => {
                moveTo(".education");
              }}
            >
              <p>Ta'lim</p>
            </Link>
            <Link
              to="/skills"
              onClick={() => {
                moveTo(".skills");
              }}
            >
              <p>Mahorat</p>
            </Link>
            <Link
              to="/experience"
              onClick={() => {
                moveTo(".experience");
              }}
            >
              <p>Malaka</p>
            </Link>
            <Link
              to="/contact"
              onClick={() => {
                moveTo(".contacts");
              }}
            >
              <p>Aloqaga chiqish</p>
            </Link>
          </div>
        </Fade>

        <div className="close" onClick={() => setShow(!show)}>
          <div className="span"></div>
          <div className="span"></div>
        </div>
      </div>
      <button onClick={() => setShow(!show)}>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </button>
    </nav>
  );
}

export default Navbar;
