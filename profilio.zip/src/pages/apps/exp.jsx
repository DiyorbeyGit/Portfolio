import "../styles/exp.scss";
import Exp from "../../images/exp.svg";
import im from "../../images/portfel.svg";
import Fade from "react-reveal/Fade";

function Experience() {
  return (
    <div className="experience">
      <div className="experience-body">
        <div className="experience-image">
          <img src={Exp} alt="" />
        </div>

        <div className="experience-description">
          <h1>Malaka</h1>

          <Fade right>
            <div className="experience-card">
              <div className="expcard-img">
                <img src={im} alt="" />
              </div>
              <div className="experience-details">
                <h6>2022-2023</h6>
                <h4>Frontend Dasturchi</h4>
                <h5>IT center</h5>
              </div>
            </div>
          </Fade>

          <Fade right>
            <div className="experience-card">
              <div className="expcard-img">
                <img src={im} alt="" />
              </div>
              <div className="experience-details">
                <h6>2023</h6>
                <h4>Backend Developer</h4>
                <h5>IT center</h5>
              </div>
            </div>
          </Fade>
        </div>
      </div>
    </div>
  );
}

export default Experience;
