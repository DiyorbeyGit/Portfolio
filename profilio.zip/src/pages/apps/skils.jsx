import "../styles/skils.scss";
import Marquee from "react-fast-marquee";
import { skills } from "../../key";

function Skills() {
  return (
    <div className="skills">
      <div className="title">
        <h1>Mahorat</h1>
      </div>
      <div className="bottom">
        <Marquee
          gradient={false}
          speed={150}
          pauseOnHover={true}
          pauseOnClick={true}
          delay={0}
          play={true}
          direction="right"
        >
          {skills.map((e) => {
            return (
              <div className="const">
                <div className="name">{e.name}</div>
                <div className="logo">
                  <img src={e.image} alt="" />
                </div>
                <div className="pratsent">
                  <div className="line">
                    <span style={{ width: e.foiz }} />
                    <div className="foiz" style={e.foiz.length<4?{ color: "#7066ff" }:{color:"#fff"}}>{e.foiz}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </Marquee>
      </div>
    </div>
  );
}

export default Skills;
