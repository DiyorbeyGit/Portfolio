import "../styles/education.scss";
import Edu from "../../images/edu.svg";
import Eduin from "../../images/eduin.svg";
import Fade from "react-reveal/Fade";
import Bounce from "react-reveal/Bounce";
import CountUp from 'react-countup';
function Education() {
  return (
    <div className="education">
      <div className="education-body">
        <h1>Ta'lim</h1>
        <Fade left cascade>
          <div className="education-description">
            <div className="education-card">
              <div className="educard-img">
                <img src={Edu} alt="img" />
              </div>
              <div className="education-details">
                <h6><CountUp start={0} end={2010} enableScrollSpy scrollSpyDelay={100} duration={2} child=''/>-<CountUp start={0} end={2013} enableScrollSpy scrollSpyDelay={100} duration={2} child=''/></h6>
                <h4>Maktabgacha ta'lim</h4>
                <h5>4-sonlili maktabgacha ta'lim muassasasi</h5>
              </div>
            </div>
            <div className="education-card">
              <div className="educard-img">
                <img src={Edu} alt="img" />
              </div>
              <div className="education-details">
                <h6><CountUp start={0} end={2013} enableScrollSpy scrollSpyDelay={100} duration={2} child=''/>-<CountUp start={0} end={2025} enableScrollSpy scrollSpyDelay={100} duration={2} child=''/></h6>
                <h4>Boshlang'ich ta'lim</h4>
                <h5>Jalaquduqdagi 1-maktab</h5>
              </div>
            </div>

            <div className="education-card">
              <div className="educard-img">
                <img src={Edu} alt="" />
              </div>
              <div className="education-details">
                <h6><CountUp start={0} end={2025} enableScrollSpy scrollSpyDelay={100} duration={2} child=''/>-<CountUp start={0} end={2029} enableScrollSpy scrollSpyDelay={100} duration={2} child=''/></h6>
                <h4>Bankning nufuzli xodimi</h4>
                <h5>Iqtisodiyot Universiteti, Andijon</h5>
              </div>
            </div>
          </div>
        </Fade>

        <Bounce top>
          <div className="education-image">
            <img src={Eduin} alt="" />
          </div>
        </Bounce>
      </div>
    </div>
  );
}

export default Education;
