import "../styles/about.scss";
import Boy from "../../images/bo.png";
import LightSpeed from "react-reveal/LightSpeed";
import Fade from "react-reveal/Fade";

function About() {
  return (
    <div className="about">
      <div className="line-styling">
        <div className="style-circle"></div>
        <div className="style-circle"></div>
        <div className="style-line"></div>
      </div>
      <div className="about-body">
        
        <Fade left cascade>
        <div className="about-description">
          <h2>Men haqimda</h2>
          <p>
            Mening ismim Diyorbek. Men O'zbekistondagi Andijonning Jalaquduqlik
            veb-dasturchiman.
            <br />
            <br />
            Kunduzi men tumanimdagi maktabga o'qish uchun boraman, maktabdan
            so'ng to'garak mashg'ulotlarimga, kechqurun esa oilam bilan vaqt
            o'tkazaman va vaqtimni oʻz foydali mashg'ulotlarga uchun sarflayman.
            Bo‘sh vaqtimni deyarli yo'q desa ham bo'ladi albatda yakshanba
            kunidan tashqari.
          </p>
        </div>
        </Fade>

        <LightSpeed right>
          <div className="about-img">
            <img src={Boy} alt="" />
          </div>
        </LightSpeed>
      </div>
    </div>
  );
}

export default About;
