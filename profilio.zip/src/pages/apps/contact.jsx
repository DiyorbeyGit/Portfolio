import "../styles/contact.scss";
import Svg from "../../images/contact.svg";
import Send from "../../images/send.svg";
import Map from "../../images/map.svg";
import Mail from "../../images/mail.svg";
import Phone from "../../images/phone.svg";
import Slide from "react-reveal/Slide";
import Bounce from "react-reveal/Bounce";
import Roll from "react-reveal/Roll";
import Zoom from "react-reveal/Zoom";
import Shake from "react-reveal/Shake";

function Contact() {
  return (
    <div class="contacts">
      <Slide left cascade>
        <div className="form">
          <h1>Aloqaga chiqish</h1>
          <div className="inps">
            <input type="text" placeholder="Ismingiz" />
          </div>
          <div className="inps">
            <input type="mail" placeholder="E-pchta" />
          </div>
          <div className="inps">
            <input type="phone" placeholder="Raqamingiz" />
          </div>
          <textarea placeholder="Xabaringiz"></textarea>
          <div className="btn">
            <button>
              Send
              <img src={Send} alt="" />
            </button>
          </div>
        </div>
      </Slide>

      <div className="info">
        <Bounce top cascade>
          <div className="touch">
            <div className="const">
              <img src={Map} alt="" />{" "}
              <h1>O'zbekiston Andijon Jalaquduq A.Ibragimov №11</h1>
            </div>
            <div className="const">
              <img src={Mail} alt="" /> <h1>dgwww.1122@gmail.com</h1>
            </div>
            <div className="const">
              <img src={Phone} alt="" /> <h1>+998 (94) 449-17-12</h1>
            </div>
          </div>
        </Bounce>
        <div className="social">
          <Zoom left>
            <h1>Aloqaga chiqish uchun :</h1>
          </Zoom>
          <Roll bottom cascade>
            <div className="icons">
              <i class="fa-brands fa-github"></i>
              <i class="fa-brands fa-instagram"></i>
              <i class="fa-brands fa-telegram"></i>
              <i class="fa-brands fa-youtube"></i>
              <i class="fa-solid fa-phone"></i>
            </div>
          </Roll>
        </div>
      </div>

      <Shake>
        <div className="img">
          <img src={Svg} alt="" />
        </div>
      </Shake>
    </div>
  );
}

export default Contact;
