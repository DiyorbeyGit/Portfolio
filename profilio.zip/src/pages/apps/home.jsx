import "../styles/home.scss";
import myportrate from "../../images/lion.jpg";
import { Link } from "react-router-dom";

function Home() {
  const moveTo = (e) => {
    const to = document.querySelector(e).offsetTop;
    window.scrollTo({
      top: to,
      behavior: "smooth",
    });
  };
  function move(e) {
    document.querySelector(".landing--img").style.top = "-" + e.clientY * 0.01 + "px";
    document.querySelector(".landing--img").style.left = "-" + e.clientX * 0.01 + "px";
  }
  return (
    <div className="landing" onMouseMove={(e) => move(e)}>
      <div className="landing--container">
        <div className="landing--container-left">
          <div className="lcl--content">
            <i className="fa-brands fa-github"></i>
            <i className="fa-brands fa-instagram"></i>
            <i className="fa-brands fa-telegram"></i>
            <i className="fa-brands fa-youtube"></i>
            <i className="fa-solid fa-phone"></i>
          </div>
        </div>
          <div className="img">
            <img src={myportrate} alt="img" className="landing--img" />
          </div>
        <div className="landing--container-right">
          <div className="lcr--content">
            <h6>Web Dsturchi</h6>
            <h1>Diyorbek G'anijonov</h1>
            <p>
              Yer shari sirtining markaziy qismi O'rta Osiyoning markazi
              bo'lmish O'zbekistondagi Andijon viloyatining chekka bir
              tumanidagi dasturchi bo'lmoqchi bo'lgan yigiting orzu niyatlari va
              erishgan narsalari haqida bilib oling. Men bilan aloqaga chiqing.
              Murakkab va chalkash masalalar va topshiriqlarda yordam berishda
              har vaqt va har soniya tayyorman !!!
            </p>
            <div className="lcr-buttonContainer">
              <button>
                <Link
                  to="/contact"
                  onClick={() => {
                    moveTo(".contacts");
                  }}
                >
                  Xabarlashish <i className="fa-regular fa-paper-plane"></i>
                </Link>
              </button>
              <button>
                <a href="https://t.me/dganijonov1122">Telegram</a>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
