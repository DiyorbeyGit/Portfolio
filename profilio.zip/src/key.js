import CSS from './images/css.svg';
import HTML from './images/html.svg';
import JS from './images/js.svg';
import React from './images/react.svg';
import DB from './images/mongodb.svg';
import SASS from './images/SASS.svg';
import Bot from './images/bot.svg';
export const skills = [
    {
        name: 'CSS',
        foiz: '100%',
        image: CSS
    },
    {
        name: 'SCSS',
        foiz: '100%',
        image: SASS
    },
    {
        name: 'HTML',
        foiz: '100%',
        image: HTML
    },
    {
        name: 'JavaScript',
        foiz: '70%',
        image: JS
    },
    {
        name: 'React',
        foiz: '60%',
        image: React
    },
    {
        name: 'MongoDB',
        foiz: '40%',
        image: DB
    },
    {
        name: 'TeleBot',
        foiz: '50%',
        image: Bot
    }
]