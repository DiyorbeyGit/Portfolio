import '../styles/etc.scss';
function ETC({show}) {
    return ( 
        <>
        <button onClick={()=>{
            const to = document.querySelector('nav').offsetTop
            window.scrollTo({
                top: to,
                behavior: 'smooth'
            });
        }} className={!show?"down":"down active"}>
            <i className="fas fa-circle-up"></i>
        </button>

        <div id="cursour"></div>
        <div id="cursour2"></div>
        <div id="cursour3"></div>
        </>
     );
}

export default ETC;